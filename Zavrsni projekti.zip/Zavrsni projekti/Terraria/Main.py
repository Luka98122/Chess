import pygame
import random
import Player

GAME_WIDTH = 500
GAME_HEIGHT = 50
CAMERA_X = 0
CAMERA_Y = 0
BLOCK_SIZE = 32
# Blocks
AIR = 0
DIRT = 1
GRASS = 2
STONE = 3
WOOD_PLATFORM = 4

colors_dict = {
    AIR : pygame.Color("Cyan"),
    DIRT : pygame.Color("Brown"),
    GRASS : pygame.Color("chartreuse2"),
    STONE : pygame.Color("Grey"),
    WOOD_PLATFORM : None 
}

img_dict = {
    WOOD_PLATFORM : pygame.transform.scale(pygame.image.load("Textures\\Wood_Platform.png"), (BLOCK_SIZE,BLOCK_SIZE))
}


def blur_generate_world(blurAmount):
    world = generate_world()
    listToBlur = []
    for i in range(GAME_WIDTH+blurAmount):
        listToBlur.append(random.randint(0,10))
    
    for i in range(GAME_WIDTH):
        height = int((listToBlur[i]+listToBlur[i+1]+listToBlur[i+2])/blurAmount)
        for j in range(height):
            world[29-j][i] = DIRT
    return world


def smart_generate_world():
    world = generate_world() # Generate flat world, that hills will be added too
    num_of_hills = random.randint(int(GAME_WIDTH/10), int(GAME_WIDTH/5)) # Number of hills to be generated
    for i in range(num_of_hills):
        while True:
            x = random.randint(5,GAME_WIDTH-16) # Start x position of hill
            if world[29][x] == AIR:
                break
        height = random.randint(5,12) # Height of generated hill
        for j in range(height):
            for z in range(x, x+random.randint(5,15)): # Width
                prob = random.randint(0,100)
                if prob<97:
                    if world[29-j+1][z] != AIR:
                       world[29-j][z] = GRASS
                       world[29-j+1][z] = DIRT       
    return world

def generate_world(): # Generate flat world split into layers
    world = []
    for i in range(GAME_HEIGHT):
        world.append([])
        for j in range(GAME_WIDTH):
            block = None
            if i > 0 and i < 30:
                block = AIR
            elif i >=30 and i < 40:
                block = DIRT
            elif i >= 40 and i < 45:
                block = DIRT
            else:
                block = STONE
            world[i].append(block) 
    return world


def draw_world(window,world): # Draw the world
    counter = 0
    for i in range(GAME_HEIGHT):
        for j in range(GAME_WIDTH):
            if counter != 0:
                counter -= 1
                continue
            color = colors_dict[world[i][j]]
            if color == None:
                counter = 1
                while True:
                    if world[i][j+counter] == world[i][j]:
                        counter +=1
                    else:
                        break
                img = pygame.transform.scale(img_dict[world[i][j]], (BLOCK_SIZE*counter,BLOCK_SIZE))
                window.blit(img, pygame.Rect(j*BLOCK_SIZE, i*BLOCK_SIZE, BLOCK_SIZE*counter, BLOCK_SIZE))
                print("Drew it")
                continue
            if j-CAMERA_X >-1 and abs(player.x - (j)) < 60:
                pygame.draw.rect(window, color, pygame.Rect((j-CAMERA_X)*BLOCK_SIZE,(i-CAMERA_Y)*BLOCK_SIZE,BLOCK_SIZE,BLOCK_SIZE))
                #pygame.draw.rect(window, pygame.Color("Black"), pygame.Rect((j-CAMERA_X)*BLOCK_SIZE,(i-CAMERA_Y)*BLOCK_SIZE,BLOCK_SIZE,BLOCK_SIZE),1)

window = pygame.display.set_mode((800,800))
clock = pygame.time.Clock()
world = blur_generate_world(4)


def applyGrassLayer(world):
    for i in range(GAME_WIDTH):
        for j in range(1,GAME_HEIGHT):
            if i-CAMERA_X >-1 and abs(player.x - (i)) < 60:
                if world[GAME_HEIGHT-j][i] == AIR:
                    world[GAME_HEIGHT-j+1][i] = GRASS
                    break
                    
                




player = Player.Player(5,5)
player.accuracy = 1
while True: # Main game loop
    window.fill("Cyan")
    events = pygame.event.get()
    for event in events:
        if event.type == pygame.QUIT:
            exit()
    
    keys = pygame.key.get_pressed()
    CAMERA_X,CAMERA_Y = player.update(keys,world, CAMERA_X, CAMERA_Y)
    
    mousePos = pygame.mouse.get_pos()
    mouseState = pygame.mouse.get_pressed()
    
    world = player.build(mouseState,mousePos, world)
    
    applyGrassLayer(world)
    draw_world(window,world)
    player.draw(window, CAMERA_X, CAMERA_Y)
    img = pygame.transform.scale(img_dict[WOOD_PLATFORM], (BLOCK_SIZE*5,BLOCK_SIZE))
    window.blit(img, pygame.Rect(0*BLOCK_SIZE, 5*BLOCK_SIZE, BLOCK_SIZE*5, BLOCK_SIZE))
    
    #Update Display
    pygame.display.update()
    clock.tick(60)