import pygame
import math
BLOCK_SIZE = 32
class Player:
    img = pygame.image.load("Textures\\Player.png")
    img = pygame.transform.scale(img, (BLOCK_SIZE,BLOCK_SIZE))
    accuracy = 1
    ddy = 2
    dx = 0
    dy = 5
    def __init__(self,x,y) -> None:
        self.x = x
        self.y = y
    
    def update(self,keys,world, cameraX, cameraY):
        self.dx = 0
        self.dy += self.ddy
        if self.dy > 2:
            self.dy = 1*self.accuracy
        if keys[pygame.K_a]:
            self.dx = -1*self.accuracy
        if keys[pygame.K_d]:
            self.dx = 1*self.accuracy
        if keys[pygame.K_SPACE] and world[int(self.y+1)][int(self.x)] != 0:
            self.dy = -5*self.accuracy
        else:
            if self.y > 29 and self.y < 30:
                self.y = 30
        for i in range(self.accuracy):
            try:
                if self.x+self.dx/self.accuracy>=0:
                    if world[int(self.y)][math.ceil(self.x+self.dx/self.accuracy)] == 0 and self.dx != 0:
                        self.x += self.dx/self.accuracy
                        cameraX += self.dx/self.accuracy
                        print(f"Moved x {self.x}")
            except:
                pass
            
            try:
                if self.y + self.dy/self.accuracy > 0:
                    if world[math.ceil(self.y+self.dy/self.accuracy)][int(self.x)] == 0 and self.dy != 0:
                        self.y += self.dy / self.accuracy
                        cameraY += self.dy / self.accuracy
                        print(f"Moved y {self.y}")
            except:
                pass
            return [cameraX,cameraY]
    
    def build(self, mouseState, mousePos, world):
        if mouseState[0]:
            x = int(mousePos[0]//BLOCK_SIZE)
            y = int(mousePos[1]//BLOCK_SIZE)
            world[y][x] = 4
        return world
            
    
    def draw(self,window : pygame.surface, CAMERA_X, CAMERA_Y):
        window.blit(self.img, pygame.Rect((self.x-CAMERA_X)*BLOCK_SIZE,(self.y-CAMERA_Y)*BLOCK_SIZE,BLOCK_SIZE,BLOCK_SIZE))